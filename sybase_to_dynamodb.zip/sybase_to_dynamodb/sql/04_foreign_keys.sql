-- =============================================================================
-- 04_foreign_keys.sql  (run in SQuirreL against the Sybase ASE database)
-- Foreign keys (up to 8 columns each). DynamoDB cannot enforce these, so they are
-- stored in the schema catalog and checked by the validation script.
-- Export the result as:  schema_export/foreign_keys.csv
-- (If the query returns no rows you can skip this file.)
-- =============================================================================
SELECT user_name(o.uid)                 AS owner,
       o.name                           AS table_name,
       object_name(r.constrid)          AS constraint_name,
       user_name(ro.uid)                AS ref_owner,
       ro.name                          AS ref_table,
       col_name(r.tableid, r.fokey1)    AS fk_col1,
       col_name(r.tableid, r.fokey2)    AS fk_col2,
       col_name(r.tableid, r.fokey3)    AS fk_col3,
       col_name(r.tableid, r.fokey4)    AS fk_col4,
       col_name(r.tableid, r.fokey5)    AS fk_col5,
       col_name(r.tableid, r.fokey6)    AS fk_col6,
       col_name(r.tableid, r.fokey7)    AS fk_col7,
       col_name(r.tableid, r.fokey8)    AS fk_col8,
       col_name(r.reftabid, r.refkey1)  AS ref_col1,
       col_name(r.reftabid, r.refkey2)  AS ref_col2,
       col_name(r.reftabid, r.refkey3)  AS ref_col3,
       col_name(r.reftabid, r.refkey4)  AS ref_col4,
       col_name(r.reftabid, r.refkey5)  AS ref_col5,
       col_name(r.reftabid, r.refkey6)  AS ref_col6,
       col_name(r.reftabid, r.refkey7)  AS ref_col7,
       col_name(r.reftabid, r.refkey8)  AS ref_col8
FROM   sysreferences r
JOIN   sysobjects o  ON o.id  = r.tableid
JOIN   sysobjects ro ON ro.id = r.reftabid
WHERE  r.reftabid IS NOT NULL
ORDER  BY 1, 2, 3
