-- =============================================================================
-- 02_columns.sql  (run in SQuirreL against the Sybase ASE database)
-- Export the result as:  schema_export/columns.csv
-- =============================================================================
SELECT user_name(o.uid) AS owner,
       o.name           AS table_name,
       c.colid          AS ordinal,
       c.name           AS column_name,
       t.name           AS type_name,
       c.length         AS length,
       c.prec           AS prec,
       c.scale          AS scale,
       CASE WHEN (c.status & 8)   = 8   THEN 1 ELSE 0 END AS nullable,
       CASE WHEN (c.status & 128) = 128 THEN 1 ELSE 0 END AS is_identity,
       d.text           AS default_value
FROM   sysobjects o
JOIN   syscolumns c ON c.id = o.id
JOIN   systypes   t ON t.usertype = c.usertype
LEFT   JOIN syscomments d ON d.id = c.cdefault AND d.colid = 1
WHERE  o.type = 'U'
  AND  o.name NOT LIKE 'sys%'
  AND  o.name NOT LIKE 'rs[_]%'
ORDER  BY 1, 2, 3
