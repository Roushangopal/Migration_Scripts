-- =============================================================================
-- 03_indexes.sql  (run in SQuirreL against the Sybase ASE database)
-- Primary keys + unique + non-unique indexes, one row per index column.
-- Export the result as:  schema_export/indexes.csv
-- =============================================================================
SELECT user_name(o.uid) AS owner,
       o.name           AS table_name,
       i.name           AS index_name,
       i.indid          AS index_id,
       CASE WHEN (i.status & 2048) = 2048 THEN 1 ELSE 0 END AS is_primary_key,
       CASE WHEN (i.status & 2)    = 2    THEN 1 ELSE 0 END AS is_unique,
       CASE WHEN i.indid = 1 THEN 1 ELSE 0 END               AS is_clustered,
       n.colid          AS key_ordinal,
       index_col(o.name, i.indid, n.colid, o.uid) AS column_name
FROM   sysobjects o
JOIN   sysindexes i ON i.id = o.id
JOIN   syscolumns n ON n.id = o.id AND n.colid <= i.keycnt
WHERE  o.type = 'U'
  AND  i.indid > 0 AND i.indid < 255
  AND  o.name NOT LIKE 'sys%'
  AND  o.name NOT LIKE 'rs[_]%'
  AND  index_col(o.name, i.indid, n.colid, o.uid) IS NOT NULL
ORDER  BY 1, 2, 4, 8
