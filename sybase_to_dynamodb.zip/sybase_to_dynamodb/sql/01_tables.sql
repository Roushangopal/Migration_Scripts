-- =============================================================================
-- 01_tables.sql  (run in SQuirreL against the Sybase ASE database)
-- Export the result as:  schema_export/tables.csv
-- =============================================================================
SELECT user_name(o.uid) AS owner,
       o.name           AS table_name,
       o.id             AS object_id
FROM   sysobjects o
WHERE  o.type = 'U'
  AND  o.name NOT LIKE 'sys%'
  AND  o.name NOT LIKE 'rs[_]%'
ORDER  BY 1, 2
