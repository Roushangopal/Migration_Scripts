#!/usr/bin/env python3
"""
STEP 4 - Create the DynamoDB tables (+ GSIs) and store the full Sybase schema catalog in DynamoDB.

  python 02_create_dynamodb_tables.py --dry-run     # preview only
  python 02_create_dynamodb_tables.py               # create tables
  python 02_create_dynamodb_tables.py --skip-catalog

The catalog table `_sybase_schema_catalog` (key: table_name) holds one item per table with the original
Sybase column types, nullability, defaults, identity flags, indexes and foreign keys, so the
relational schema is preserved and queryable after migration.
"""
import argparse
import glob
import json
import os
from decimal import Decimal

import boto3
from botocore.exceptions import ClientError

from common import CATALOG_TABLE, load_catalog, load_config


def table_exists(client, name):
    try:
        client.describe_table(TableName=name)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceNotFoundException":
            return False
        raise


def create_and_wait(client, definition):
    client.create_table(**definition)
    client.get_waiter("table_exists").wait(TableName=definition["TableName"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--skip-catalog", action="store_true")
    args = ap.parse_args()

    cfg = load_config()
    out_dir = cfg["paths"]["output_dir"]
    files = sorted(glob.glob(os.path.join(out_dir, "tables", "*.json")))
    if not files:
        raise SystemExit("No table definitions found - run 01_generate_dynamodb_schema.py first.")

    res = boto3.resource("dynamodb", region_name=cfg["aws_region"],
                         endpoint_url=cfg.get("dynamodb_endpoint_url"))
    client = res.meta.client

    # ---- catalog table ----------------------------------------------------
    if not args.skip_catalog:
        if args.dry_run:
            print(f"[dry-run] would ensure catalog table {CATALOG_TABLE}")
        elif not table_exists(client, CATALOG_TABLE):
            print(f"Creating catalog table {CATALOG_TABLE} ...")
            create_and_wait(client, {
                "TableName": CATALOG_TABLE,
                "AttributeDefinitions": [{"AttributeName": "table_name", "AttributeType": "S"}],
                "KeySchema": [{"AttributeName": "table_name", "KeyType": "HASH"}],
                "BillingMode": "PAY_PER_REQUEST",
            })

    # ---- data tables ------------------------------------------------------
    created = skipped = 0
    for path in files:
        with open(path, encoding="utf-8") as f:
            definition = json.load(f)
        name = definition["TableName"]
        if args.dry_run:
            gsis = len(definition.get("GlobalSecondaryIndexes", []))
            print(f"[dry-run] would create {name} (GSIs: {gsis})")
            continue
        if table_exists(client, name):
            print(f"exists  {name}")
            skipped += 1
            continue
        print(f"create  {name} ...", flush=True)
        create_and_wait(client, definition)
        created += 1

    # ---- catalog items ----------------------------------------------------
    if not args.skip_catalog and not args.dry_run:
        cat_table = res.Table(CATALOG_TABLE)
        catalog = json.loads(json.dumps(load_catalog(cfg)), parse_float=Decimal)
        for entry in catalog:
            cat_table.put_item(Item=entry)
        print(f"Stored {len(catalog)} schema entries in {CATALOG_TABLE}")

    if not args.dry_run:
        print(f"Done. created={created} already-existing={skipped}")


if __name__ == "__main__":
    main()
