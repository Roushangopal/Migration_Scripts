#!/usr/bin/env python3
"""
STEP 7 - Validate the migration.

Checks per table:
  1. Row count: Sybase vs DynamoDB (exact, consistent scan)
  2. Spot check: N random CSV rows are re-read from DynamoDB and compared attribute by attribute
  3. Unique indexes: duplicate check on the CSV data (DynamoDB cannot enforce uniqueness)
  4. Foreign keys: orphan check on the CSV data (DynamoDB cannot enforce FKs)

Source counts come from output/source_counts.csv (export of output/row_counts.sql run in SQuirreL),
or live from Sybase with --jdbc.

  python 05_validate.py --spot-check 200
  python 05_validate.py --jdbc --spot-check 200 --tables dbo.orders
"""
import argparse
import csv
import os
import random
import sys

import boto3
from boto3.dynamodb.types import Binary

from common import (build_item, find_data_file, iter_csv_rows, load_catalog, load_config,
                    read_csv_dicts)


def dynamo_count(table):
    kwargs, total = {"Select": "COUNT", "ConsistentRead": True}, 0
    while True:
        r = table.scan(**kwargs)
        total += r["Count"]
        if "LastEvaluatedKey" not in r:
            return total
        kwargs["ExclusiveStartKey"] = r["LastEvaluatedKey"]


def source_counts(cfg, catalog, use_jdbc):
    if use_jdbc:
        import jaydebeapi
        sy = cfg["sybase"]
        pwd = os.environ.get(sy["password_env"]) or sys.exit(f'set {sy["password_env"]}')
        conn = jaydebeapi.connect(sy["driver_class"], sy["jdbc_url"], [sy["user"], pwd], sy["jar_path"])
        out = {}
        for t in catalog:
            cur = conn.cursor()
            cur.execute(f'SELECT COUNT(*) FROM {t["source_key"]}')
            out[t["source_key"].lower()] = int(cur.fetchone()[0])
            cur.close()
        conn.close()
        return out
    path = os.path.join(cfg["paths"]["output_dir"], "source_counts.csv")
    return {r["table_name"].lower(): int(float(r["row_count"])) for r in read_csv_dicts(path)}


def norm(item):
    return {k: (bytes(v.value) if isinstance(v, Binary) else v) for k, v in item.items()}


def spot_check(cfg, tdef, table, n):
    ks = tdef["key_schema"]
    path = find_data_file(cfg, tdef)
    if not path or ks["synthetic_row_id"] or n <= 0:
        return 0, 0
    sample = []
    for i, (line, row) in enumerate(iter_csv_rows(path)):       # reservoir sampling
        if len(sample) < n:
            sample.append((line, row))
        else:
            j = random.randint(0, i)
            if j < n:
                sample[j] = (line, row)
    checked = bad = 0
    for line, row in sample:
        try:
            item = build_item(row, tdef, cfg["key_delimiter"], cfg["trim_char_columns"], line)
        except Exception:  # noqa: BLE001 - such rows are in the loader error file
            continue
        key = {ks["hash"]: item[ks["hash"]]}
        if ks["range"]:
            key[ks["range"]] = item[ks["range"]]
        got = table.get_item(Key=key, ConsistentRead=True).get("Item")
        checked += 1
        if got is None or norm(got) != item:
            bad += 1
    return checked, bad


def check_unique(cfg, tdef):
    """Return {index_name: duplicate_count} for unique source indexes (non-PK) using CSV data."""
    path = find_data_file(cfg, tdef)
    uniques = [i for i in tdef["source_indexes"] if i["unique"] and not i["primary_key"]]
    if not path or not uniques:
        return {}
    seen = {i["index_name"]: set() for i in uniques}
    dups = {i["index_name"]: 0 for i in uniques}
    for _, row in iter_csv_rows(path):
        for i in uniques:
            vals = tuple((row.get(c.lower()) or "").strip() for c in i["columns"])
            if any(v == "" for v in vals):        # NULLs are not compared
                continue
            if vals in seen[i["index_name"]]:
                dups[i["index_name"]] += 1
            seen[i["index_name"]].add(vals)
    return {k: v for k, v in dups.items() if v}


def check_fks(cfg, tdef, by_key):
    """Return {constraint: orphan_count} using the CSV files of child and parent tables."""
    out = {}
    path = find_data_file(cfg, tdef)
    if not path:
        return out
    for fk in tdef["foreign_keys"]:
        parent = by_key.get(f'{fk["ref_owner"]}.{fk["ref_table"]}')
        ppath = find_data_file(cfg, parent) if parent else None
        if not ppath or not fk["columns"]:
            continue
        pvals = set()
        for _, row in iter_csv_rows(ppath):
            pvals.add(tuple((row.get(c.lower()) or "").strip() for c in fk["ref_columns"]))
        orphans = 0
        for _, row in iter_csv_rows(path):
            vals = tuple((row.get(c.lower()) or "").strip() for c in fk["columns"])
            if any(v == "" for v in vals):
                continue
            if vals not in pvals:
                orphans += 1
        if orphans:
            out[fk["constraint_name"]] = orphans
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tables", nargs="*")
    ap.add_argument("--jdbc", action="store_true", help="count rows live in Sybase")
    ap.add_argument("--spot-check", type=int, default=100)
    ap.add_argument("--skip-constraint-checks", action="store_true")
    args = ap.parse_args()

    cfg = load_config()
    catalog = load_catalog(cfg)
    wanted = {t.lower() for t in args.tables} if args.tables else None
    todo = [t for t in catalog if not wanted or t["source_key"].lower() in wanted]
    by_key = {t["source_key"]: t for t in catalog}
    src = source_counts(cfg, todo, args.jdbc)
    res = boto3.resource("dynamodb", region_name=cfg["aws_region"],
                         endpoint_url=cfg.get("dynamodb_endpoint_url"))

    rows, failures = [], 0
    for t in todo:
        table = res.Table(t["table_name"])
        s = src.get(t["source_key"].lower())
        d = dynamo_count(table)
        checked, bad = spot_check(cfg, t, table, args.spot_check)
        udups = fk_orph = {}
        if not args.skip_constraint_checks:
            udups, fk_orph = check_unique(cfg, t), check_fks(cfg, t, by_key)
        ok = (s == d) and bad == 0 and not udups and not fk_orph
        failures += 0 if ok else 1
        print(f'{"OK  " if ok else "FAIL"} {t["source_key"]:<40} sybase={s} dynamodb={d} '
              f'spot={checked - bad}/{checked}'
              + (f" unique_dups={udups}" if udups else "") + (f" fk_orphans={fk_orph}" if fk_orph else ""))
        rows.append([t["source_key"], t["table_name"], s, d, checked, bad,
                     str(udups) if udups else "", str(fk_orph) if fk_orph else "", "OK" if ok else "FAIL"])

    out = os.path.join(cfg["paths"]["output_dir"], "validation_report.csv")
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["source", "dynamodb_table", "sybase_rows", "dynamodb_items", "spot_checked",
                    "spot_mismatches", "unique_violations", "fk_orphans", "status"])
        w.writerows(rows)
    print(f"\n{len(todo) - failures}/{len(todo)} tables OK. Report: {out}")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
