"""Shared helpers for the Sybase ASE -> DynamoDB migration scripts."""
import csv
import json
import os
import re
import sys
import uuid
from decimal import Decimal

from dateutil import parser as dtparser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_TABLE = "_sybase_schema_catalog"

csv.field_size_limit(2**31 - 1)


# --------------------------------------------------------------------------- #
# Config / IO
# --------------------------------------------------------------------------- #
def load_config(path=None):
    path = path or os.path.join(BASE_DIR, "config.json")
    with open(path, encoding="utf-8") as f:
        cfg = json.load(f)
    for k, v in cfg["paths"].items():
        cfg["paths"][k] = v if os.path.isabs(v) else os.path.join(BASE_DIR, v)
    return cfg


def read_csv_dicts(path):
    """Read a SQuirreL CSV export; header names are lower-cased, values trimmed."""
    if not os.path.exists(path):
        sys.exit(f"ERROR: missing file {path}\n"
                 f"Run the matching SQL script in SQuirreL and export the result to that path.")
    with open(path, newline="", encoding="utf-8-sig") as f:
        return [{(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
                for row in csv.DictReader(f)]


def iter_csv_rows(path):
    """Yield (line_no, row_dict) with lower-cased header names. Values untouched."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        for i, row in enumerate(csv.DictReader(f), start=2):
            yield i, {(k or "").strip().lower(): v for k, v in row.items()}


def load_catalog(cfg):
    path = os.path.join(cfg["paths"]["output_dir"], "catalog.json")
    if not os.path.exists(path):
        sys.exit("ERROR: output/catalog.json not found - run 01_generate_dynamodb_schema.py first.")
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def find_data_file(cfg, tdef):
    d = cfg["paths"]["data_dir"]
    candidates = [
        f'{tdef["source_owner"]}.{tdef["source_table"]}.csv',
        f'{tdef["source_table"]}.csv',
        f'{tdef["source_table"].lower()}.csv',
    ]
    for c in candidates:
        p = os.path.join(d, c)
        if os.path.exists(p):
            return p
    return None


# --------------------------------------------------------------------------- #
# Naming
# --------------------------------------------------------------------------- #
def sanitize(name):
    s = re.sub(r"[^A-Za-z0-9_.\-]", "_", name)
    return s.ljust(3, "_")[:255]


def dynamo_table_name(cfg, owner, table):
    base = table if owner.lower() == cfg["default_owner"].lower() else f"{owner}_{table}"
    return sanitize(cfg["table_prefix"] + base)


# --------------------------------------------------------------------------- #
# Sybase type -> DynamoDB type
#   kind:  N=number  S=string  BOOL=boolean  B=binary
#          DT=datetime (ISO string)  D=date (ISO string)  T=time (string)
# --------------------------------------------------------------------------- #
_NUMERIC = {"tinyint", "smallint", "int", "integer", "bigint", "unsigned tinyint",
            "unsigned smallint", "unsigned int", "unsigned bigint", "utinyint", "usmallint",
            "uint", "ubigint", "numeric", "decimal", "float", "real", "double precision",
            "money", "smallmoney", "intn", "floatn", "numericn", "decimaln", "moneyn"}
_STRING = {"char", "varchar", "nchar", "nvarchar", "unichar", "univarchar", "text",
           "unitext", "sysname", "longsysname"}
_DATETIME = {"datetime", "smalldatetime", "bigdatetime", "datetimn"}
_DATE = {"date", "daten"}
_TIME = {"time", "bigtime", "timen"}
_BINARY = {"binary", "varbinary", "image", "timestamp"}
_BOOL = {"bit"}
LOB_TYPES = {"text", "unitext", "image"}


def classify(type_name):
    t = (type_name or "").strip().lower()
    if t in _NUMERIC:
        return "N"
    if t in _STRING:
        return "S"
    if t in _DATETIME:
        return "DT"
    if t in _DATE:
        return "D"
    if t in _TIME:
        return "T"
    if t in _BINARY:
        return "B"
    if t in _BOOL:
        return "BOOL"
    return None


def dynamo_type_for_kind(kind):
    return {"N": "N", "BOOL": "BOOL", "B": "B"}.get(kind, "S")


# --------------------------------------------------------------------------- #
# Value conversion
# --------------------------------------------------------------------------- #
def convert_value(raw, kind, dynamo_type="S", trim=True):
    """Convert a CSV string to a DynamoDB-ready Python value. None => omit attribute (NULL)."""
    if raw is None:
        return None
    if kind == "N":
        s = raw.strip()
        return Decimal(s) if s != "" else None
    if kind == "BOOL":
        s = raw.strip().lower()
        if s == "":
            return None
        flag = s in ("1", "true", "t", "y", "yes")
        return Decimal(1 if flag else 0) if dynamo_type == "N" else flag
    if kind == "B":
        s = raw.strip()
        if s == "":
            return None
        if s.lower().startswith("0x"):
            s = s[2:]
        return bytes.fromhex(s)
    if kind == "DT":
        s = raw.strip()
        return dtparser.parse(s).isoformat() if s else None
    if kind == "D":
        s = raw.strip()
        return dtparser.parse(s).date().isoformat() if s else None
    if kind == "T":
        s = raw.strip()
        return s or None
    s = raw.rstrip() if trim else raw
    return s if s != "" else None


def key_string(v):
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, Decimal):
        return format(v, "f")
    if isinstance(v, (bytes, bytearray)):
        return bytes(v).hex()
    return str(v)


def _composite(item, cols, delim, required):
    parts = []
    for c in cols:
        if c not in item:
            if required:
                raise ValueError(f"key column '{c}' is NULL/empty")
            return None
        parts.append(key_string(item[c]))
    return delim.join(parts)


def approx_size(item):
    total = 0
    for k, v in item.items():
        total += len(k.encode("utf-8"))
        if isinstance(v, (bytes, bytearray)):
            total += len(v)
        else:
            total += len(str(v).encode("utf-8"))
    return total


def build_item(row, tdef, delim, trim, row_no):
    """Turn one CSV row (dict, lower-case headers) into a DynamoDB item per the catalog."""
    item = {}
    for col in tdef["columns"]:
        val = convert_value(row.get(col["name"].lower()), col["kind"], col["dynamo_type"], trim)
        if val is not None:
            item[col["name"]] = val

    ks = tdef["key_schema"]
    if ks["synthetic_row_id"]:
        item["_row_id"] = str(uuid.uuid5(uuid.NAMESPACE_URL, f'{tdef["source_key"]}:{row_no}'))
    for attr, cols in ks["composites"].items():
        item[attr] = _composite(item, cols, delim, required=True)
    for g in tdef["gsis"]:
        for attr, cols in g["composites"].items():
            v = _composite(item, cols, delim, required=False)
            if v is not None:
                item[attr] = v

    for k in (ks["hash"], ks["range"]):
        if k and k not in item:
            raise ValueError(f"primary key attribute '{k}' is NULL/empty")
    if approx_size(item) > 400 * 1024:
        raise ValueError("item exceeds DynamoDB 400 KB limit")
    return item
