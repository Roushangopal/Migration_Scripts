#!/usr/bin/env python3
"""
STEP 6 - Load the CSV files in data/ into DynamoDB, converting types per output/catalog.json.

  python 04_load_data.py --dry-run                 # convert/validate only, write nothing
  python 04_load_data.py                           # load everything
  python 04_load_data.py --tables dbo.orders --workers 4

* Re-runnable: puts are idempotent (same key => overwritten). Synthetic _row_id values are
  deterministic (derived from table + CSV line number).
* Bad rows are NOT fatal: they are written to output/errors/<table>.errors.csv.
* NULL / empty values are omitted from the item (sparse attributes), which also keeps GSIs sparse.
"""
import argparse
import csv
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

import boto3

from common import build_item, find_data_file, iter_csv_rows, load_catalog, load_config


def load_table(cfg, tdef, dry_run):
    name, key = tdef["table_name"], tdef["source_key"]
    path = find_data_file(cfg, tdef)
    if not path:
        return key, 0, 0, "no data file found (expected data/%s.csv)" % key

    ks = tdef["key_schema"]
    pkeys = [k for k in (ks["hash"], ks["range"]) if k]
    delim, trim = cfg["key_delimiter"], cfg["trim_char_columns"]

    table = None
    if not dry_run:
        res = boto3.session.Session().resource(
            "dynamodb", region_name=cfg["aws_region"], endpoint_url=cfg.get("dynamodb_endpoint_url"))
        table = res.Table(name)

    err_dir = os.path.join(cfg["paths"]["output_dir"], "errors")
    err_path = os.path.join(err_dir, f"{key}.errors.csv")
    err_file = err_writer = None
    ok = bad = 0

    def record_error(line, msg):
        nonlocal err_file, err_writer, bad
        if err_writer is None:
            os.makedirs(err_dir, exist_ok=True)
            err_file = open(err_path, "w", newline="", encoding="utf-8")
            err_writer = csv.writer(err_file)
            err_writer.writerow(["csv_line", "error"])
        err_writer.writerow([line, msg])
        bad += 1

    def rows():
        for line_no, row in iter_csv_rows(path):
            try:
                yield build_item(row, tdef, delim, trim, line_no)
            except Exception as e:  # noqa: BLE001 - report and continue
                record_error(line_no, str(e))

    try:
        if dry_run:
            for _ in rows():
                ok += 1
        else:
            with table.batch_writer(overwrite_by_pkeys=pkeys) as bw:
                for item in rows():
                    bw.put_item(Item=item)
                    ok += 1
                    if ok % 10000 == 0:
                        print(f"  {key}: {ok:,} rows", flush=True)
    finally:
        if err_file:
            err_file.close()
    return key, ok, bad, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tables", nargs="*", help="owner.table names (default: all)")
    ap.add_argument("--workers", type=int, default=2, help="tables loaded in parallel")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = load_config()
    catalog = load_catalog(cfg)
    wanted = {t.lower() for t in args.tables} if args.tables else None
    todo = [t for t in catalog if not wanted or t["source_key"].lower() in wanted]

    total_ok = total_bad = 0
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
        futures = [ex.submit(load_table, cfg, t, args.dry_run) for t in todo]
        for fut in as_completed(futures):
            key, ok, bad, note = fut.result()
            total_ok += ok
            total_bad += bad
            status = note or f"loaded={ok:,} errors={bad:,}"
            print(f"{key}: {status}")
    print(f"\nTOTAL loaded={total_ok:,} errors={total_bad:,}"
          + ("  (dry run)" if args.dry_run else ""))
    if total_bad:
        print(f"See {os.path.join(cfg['paths']['output_dir'], 'errors')} for rejected rows.")


if __name__ == "__main__":
    main()
