#!/usr/bin/env python3
"""
STEP 5 (Option A, automated) - Extract table data from on-prem Sybase to CSV using the SAME
JDBC driver jar that SQuirreL uses (jTDS or jConnect).

  set SYBASE_PASSWORD=...            (Windows)      export SYBASE_PASSWORD=...   (Linux/macOS)
  python 03_extract_data.py                          # all tables in output/catalog.json
  python 03_extract_data.py --tables dbo.orders dbo.customers

Output: data/<owner>.<table>.csv  (header = original column names; NULL => empty cell;
        binary => hex string).

Option B (manual): in SQuirreL run `SELECT * FROM owner.table`, then export the COMPLETE result
set to CSV (UTF-8, header row, comma separator) into data/<owner>.<table>.csv.

Very large tables (tens of millions of rows): extract in key ranges or use bcp instead.
"""
import argparse
import csv
import os
import sys
from decimal import Decimal

from common import load_catalog, load_config


def connect(cfg):
    import jaydebeapi
    sy = cfg["sybase"]
    pwd = os.environ.get(sy["password_env"])
    if not pwd:
        sys.exit(f'ERROR: set the {sy["password_env"]} environment variable with the Sybase password.')
    return jaydebeapi.connect(sy["driver_class"], sy["jdbc_url"], [sy["user"], pwd], sy["jar_path"])


def fmt(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, (bytes, bytearray)):
        return bytes(v).hex()
    if isinstance(v, Decimal):
        return format(v, "f")
    if v.__class__.__name__.startswith("JArray"):          # java byte[]
        return bytes(b & 0xFF for b in v).hex()
    return str(v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tables", nargs="*", help="owner.table names (default: all)")
    ap.add_argument("--fetch-size", type=int, default=10000)
    args = ap.parse_args()

    cfg = load_config()
    catalog = load_catalog(cfg)
    wanted = {t.lower() for t in args.tables} if args.tables else None
    os.makedirs(cfg["paths"]["data_dir"], exist_ok=True)

    conn = connect(cfg)
    try:
        for tdef in catalog:
            if wanted and tdef["source_key"].lower() not in wanted:
                continue
            path = os.path.join(cfg["paths"]["data_dir"], f'{tdef["source_key"]}.csv')
            names = [c["name"] for c in tdef["columns"]]
            cur = conn.cursor()
            cur.execute(f'SELECT * FROM {tdef["source_key"]}')
            n = 0
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(names)
                while True:
                    rows = cur.fetchmany(args.fetch_size)
                    if not rows:
                        break
                    for r in rows:
                        if len(r) != len(names):
                            raise RuntimeError(f'{tdef["source_key"]}: column count mismatch '
                                               f'({len(r)} returned vs {len(names)} in catalog)')
                        w.writerow([fmt(v) for v in r])
                    n += len(rows)
                    print(f'  {tdef["source_key"]}: {n:,} rows', end="\r", flush=True)
            cur.close()
            print(f'{tdef["source_key"]}: {n:,} rows -> {path}')
    finally:
        conn.close()


if __name__ == "__main__":
    main()
