#!/usr/bin/env python3
"""
STEP 3 - Convert the Sybase catalog exports (made in SQuirreL) into DynamoDB definitions.

Reads : schema_export/tables.csv, columns.csv, indexes.csv, [foreign_keys.csv]
Writes: output/tables/<table>.json   -> input for `aws dynamodb create-table --cli-input-json`
        output/catalog.json          -> FULL Sybase schema (types, nullability, defaults, FKs, indexes)
                                        + the key mapping used. Loaded into DynamoDB by step 4.
        output/row_counts.sql        -> run in SQuirreL, export as output/source_counts.csv (for validation)
        output/schema_report.md      -> warnings & design decisions to review

Mapping rules (1 Sybase table = 1 DynamoDB table):
  * Primary key (or first all-NOT-NULL unique index, or synthetic _row_id)  -> table key
        1 column  -> HASH
        2 columns -> HASH + RANGE
        3+ cols   -> HASH = col1, RANGE = "_sk" (composite string of cols 2..n, joined by key_delimiter)
  * Every other index -> a GSI using the same pattern ("_gsiN_sk" for composites)
  * All original columns are kept as attributes with their original names.
"""
import json
import os
import re
import sys
from collections import OrderedDict

from common import (LOB_TYPES, classify, dynamo_table_name, dynamo_type_for_kind,
                    load_config, read_csv_dicts, sanitize)


def to_int(v, default=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def keyspec(cols, composite_attr):
    if len(cols) == 1:
        return {"hash": cols[0], "range": None, "composites": {}}
    if len(cols) == 2:
        return {"hash": cols[0], "range": cols[1], "composites": {}}
    return {"hash": cols[0], "range": composite_attr, "composites": {composite_attr: cols[1:]}}


def choose_primary_key(tdef, colmap):
    idxs = list(tdef["indexes"].values())
    for i in idxs:
        if i["primary_key"]:
            return i["columns"], "declared primary key"
    for i in sorted((x for x in idxs if x["unique"]), key=lambda x: not x["clustered"]):
        if all(c in colmap and not colmap[c]["nullable"] for c in i["columns"]):
            return i["columns"], f'unique index "{i["index_name"]}" (no declared PK)'
    return None, None


def main():
    cfg = load_config()
    exp_dir = cfg["paths"]["schema_export_dir"]
    out_dir = cfg["paths"]["output_dir"]
    os.makedirs(os.path.join(out_dir, "tables"), exist_ok=True)
    warnings = []
    exclude = {x.lower() for x in cfg.get("exclude_tables", [])}

    tables = read_csv_dicts(os.path.join(exp_dir, "tables.csv"))
    columns = read_csv_dicts(os.path.join(exp_dir, "columns.csv"))
    indexes = read_csv_dicts(os.path.join(exp_dir, "indexes.csv"))
    fk_path = os.path.join(exp_dir, "foreign_keys.csv")
    fks = read_csv_dicts(fk_path) if os.path.exists(fk_path) else []

    # ---- tables -----------------------------------------------------------
    tdefs = OrderedDict()
    used_names = {}
    for r in tables:
        owner, tname = r["owner"], r["table_name"]
        if f"{owner}.{tname}".lower() in exclude:
            continue
        dname = dynamo_table_name(cfg, owner, tname)
        if dname in used_names:
            sys.exit(f"ERROR: DynamoDB name collision: {owner}.{tname} and {used_names[dname]} -> {dname}. "
                     f"Set table_prefix or exclude one of them.")
        used_names[dname] = f"{owner}.{tname}"
        tdefs[(owner, tname)] = {
            "table_name": dname, "source_owner": owner, "source_table": tname,
            "source_key": f"{owner}.{tname}",
            "columns": [], "indexes": OrderedDict(), "foreign_keys": [],
        }

    # ---- columns ----------------------------------------------------------
    for r in sorted(columns, key=lambda r: (r["owner"], r["table_name"], to_int(r["ordinal"]))):
        td = tdefs.get((r["owner"], r["table_name"]))
        if not td:
            continue
        kind = classify(r["type_name"])
        if kind is None:
            warnings.append(f'{td["source_key"]}.{r["column_name"]}: unknown/user-defined type '
                            f'"{r["type_name"]}" -> stored as string')
            kind = "S"
        if r["type_name"].lower() in LOB_TYPES:
            warnings.append(f'{td["source_key"]}.{r["column_name"]}: LOB type "{r["type_name"]}" - '
                            f'DynamoDB items are limited to 400 KB; consider S3 for large values')
        td["columns"].append({
            "name": r["column_name"], "sybase_type": r["type_name"],
            "length": to_int(r["length"]), "prec": to_int(r["prec"], None) if r["prec"] else None,
            "scale": to_int(r["scale"], None) if r["scale"] else None,
            "nullable": to_int(r["nullable"]) == 1, "identity": to_int(r["is_identity"]) == 1,
            "default": r.get("default_value") or None,
            "kind": kind, "dynamo_type": dynamo_type_for_kind(kind),
        })

    # ---- indexes ----------------------------------------------------------
    for r in sorted(indexes, key=lambda r: to_int(r["key_ordinal"])):
        td = tdefs.get((r["owner"], r["table_name"]))
        if not td:
            continue
        idx = td["indexes"].setdefault(r["index_name"], {
            "index_name": r["index_name"], "primary_key": to_int(r["is_primary_key"]) == 1,
            "unique": to_int(r["is_unique"]) == 1, "clustered": to_int(r["is_clustered"]) == 1,
            "columns": []})
        idx["columns"].append(r["column_name"])

    # ---- foreign keys -----------------------------------------------------
    for r in fks:
        td = tdefs.get((r["owner"], r["table_name"]))
        if not td:
            continue
        td["foreign_keys"].append({
            "constraint_name": r["constraint_name"],
            "columns": [r[f"fk_col{i}"] for i in range(1, 9) if r.get(f"fk_col{i}")],
            "ref_owner": r["ref_owner"], "ref_table": r["ref_table"],
            "ref_columns": [r[f"ref_col{i}"] for i in range(1, 9) if r.get(f"ref_col{i}")],
        })

    # ---- build DynamoDB definitions ---------------------------------------
    catalog, count_sql = [], []
    provisioned = cfg["billing_mode"].upper() == "PROVISIONED"
    pt = {"ReadCapacityUnits": cfg["provisioned_rcu"], "WriteCapacityUnits": cfg["provisioned_wcu"]}

    for td in tdefs.values():
        colmap = {c["name"]: c for c in td["columns"]}
        name = td["table_name"]
        if not td["columns"]:
            warnings.append(f'{td["source_key"]}: no columns found in columns.csv - skipped')
            continue

        pk_cols, pk_src = choose_primary_key(td, colmap)
        if pk_cols:
            ks = keyspec(pk_cols, "_sk")
            ks["synthetic_row_id"] = False
            ks["source"] = pk_src
        else:
            ks = {"hash": "_row_id", "range": None, "composites": {}, "synthetic_row_id": True,
                  "source": "synthetic"}
            warnings.append(f'{td["source_key"]}: no primary key / usable unique index -> synthetic '
                            f'"_row_id" key (deterministic UUID per source row)')
        if len(pk_cols or []) >= 3:
            warnings.append(f'{td["source_key"]}: {len(pk_cols)}-column PK -> HASH={ks["hash"]}, '
                            f'RANGE=_sk (composite of {", ".join(ks["composites"]["_sk"])})')

        # GSIs
        used_cols = {tuple(pk_cols)} if pk_cols else set()
        gsis, skipped, gsi_names = [], [], set()
        for idx in td["indexes"].values():
            cols = idx["columns"]
            if any(c not in colmap for c in cols):
                skipped.append({"index_name": idx["index_name"], "reason": "column not found"})
                continue
            if idx["primary_key"] or tuple(cols) in used_cols:
                skipped.append({"index_name": idx["index_name"],
                                "reason": "same columns as the table key or another index"})
                continue
            if len(gsis) >= cfg["max_gsis_per_table"]:
                skipped.append({"index_name": idx["index_name"], "reason": "DynamoDB GSI limit reached"})
                warnings.append(f'{td["source_key"]}: index "{idx["index_name"]}" skipped (GSI limit)')
                continue
            used_cols.add(tuple(cols))
            gname = sanitize("gsi_" + idx["index_name"])
            base, n = gname, 2
            while gname in gsi_names:
                gname, n = f"{base}_{n}", n + 1
            gsi_names.add(gname)
            spec = keyspec(cols, f"_gsi{len(gsis) + 1}_sk")
            gsis.append({"index_name": idx["index_name"], "dynamo_name": gname, "columns": cols,
                         "unique": idx["unique"], "clustered": idx["clustered"], **spec})
            if idx["unique"]:
                warnings.append(f'{td["source_key"]}: unique index "{idx["index_name"]}" becomes a GSI - '
                                f'DynamoDB does NOT enforce uniqueness (checked by 05_validate.py instead)')

        # BOOL columns used in keys must be numbers
        key_cols = set(pk_cols or []) | {c for g in gsis for c in g["columns"]}
        for c in key_cols:
            if colmap[c]["kind"] == "BOOL":
                colmap[c]["dynamo_type"] = "N"

        attr_types = OrderedDict()

        def need(attr):
            attr_types[attr] = colmap[attr]["dynamo_type"] if attr in colmap else "S"

        need(ks["hash"])
        if ks["range"]:
            need(ks["range"])
        for g in gsis:
            need(g["hash"])
            if g["range"]:
                need(g["range"])

        def key_schema(spec):
            out = [{"AttributeName": spec["hash"], "KeyType": "HASH"}]
            if spec["range"]:
                out.append({"AttributeName": spec["range"], "KeyType": "RANGE"})
            return out

        create = {
            "TableName": name,
            "AttributeDefinitions": [{"AttributeName": a, "AttributeType": t} for a, t in attr_types.items()],
            "KeySchema": key_schema(ks),
            "BillingMode": "PROVISIONED" if provisioned else "PAY_PER_REQUEST",
            "Tags": [{"Key": "source", "Value": "sybase"},
                     {"Key": "source_table", "Value": re.sub(r"[^A-Za-z0-9 _.:/=+\-@]", "_", td["source_key"])}],
        }
        if provisioned:
            create["ProvisionedThroughput"] = pt
        if gsis:
            create["GlobalSecondaryIndexes"] = []
            for g in gsis:
                e = {"IndexName": g["dynamo_name"], "KeySchema": key_schema(g),
                     "Projection": {"ProjectionType": "ALL"}}
                if provisioned:
                    e["ProvisionedThroughput"] = pt
                create["GlobalSecondaryIndexes"].append(e)

        with open(os.path.join(out_dir, "tables", f"{name}.json"), "w", encoding="utf-8") as f:
            json.dump(create, f, indent=2)

        entry = {
            "table_name": name, "source_owner": td["source_owner"], "source_table": td["source_table"],
            "source_key": td["source_key"], "columns": td["columns"], "primary_key": pk_cols or [],
            "key_schema": ks, "gsis": gsis, "skipped_indexes": skipped,
            "source_indexes": list(td["indexes"].values()), "foreign_keys": td["foreign_keys"],
        }
        catalog.append(entry)
        count_sql.append(f"SELECT '{td['source_key']}' AS table_name, COUNT(*) AS row_count "
                         f"FROM {td['source_owner']}.{td['source_table']}")

    with open(os.path.join(out_dir, "catalog.json"), "w", encoding="utf-8") as f:
        json.dump(catalog, f, indent=2)
    with open(os.path.join(out_dir, "row_counts.sql"), "w", encoding="utf-8") as f:
        f.write("-- Run in SQuirreL as ONE statement, export result to output/source_counts.csv\n")
        f.write("\nUNION ALL\n".join(count_sql) + "\n")

    with open(os.path.join(out_dir, "schema_report.md"), "w", encoding="utf-8") as f:
        f.write(f"# Schema conversion report\n\nTables converted: {len(catalog)}\n\n")
        f.write("## Table keys\n\n| Source | DynamoDB table | HASH | RANGE | GSIs |\n|---|---|---|---|---|\n")
        for e in catalog:
            k = e["key_schema"]
            f.write(f'| {e["source_key"]} | {e["table_name"]} | {k["hash"]} | {k["range"] or ""} | {len(e["gsis"])} |\n')
        f.write("\n## Warnings / review items\n\n")
        f.write("\n".join(f"- {w}" for w in warnings) if warnings else "None")
        f.write("\n\n## Not enforceable in DynamoDB (preserved in the catalog only)\n\n"
                "- Foreign keys, CHECK constraints, defaults, IDENTITY columns, unique constraints on non-key columns\n")

    print(f"Converted {len(catalog)} tables -> {out_dir}")
    print(f"{len(warnings)} warnings - review {os.path.join(out_dir, 'schema_report.md')}")


if __name__ == "__main__":
    main()
